// Main.cpp
// Pete Myers, 4/11/2016




#include "Tests.h"


int main()
{
	Tester t;
	t.Run();

	return 0;
}
